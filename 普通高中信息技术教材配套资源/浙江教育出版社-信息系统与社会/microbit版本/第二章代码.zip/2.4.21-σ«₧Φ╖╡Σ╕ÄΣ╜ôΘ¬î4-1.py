import serial,time
ser = serial.Serial()
ser.baudrate = 115200
ser.port = 'COM3'
ser.open()
while True:
    time.sleep(1)
    ser.write('H'.encode())
    time.sleep(1)
    ser.write('S'.encode())