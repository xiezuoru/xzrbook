from microbit import *
while True:
    print(temperature())
    sleep(200)