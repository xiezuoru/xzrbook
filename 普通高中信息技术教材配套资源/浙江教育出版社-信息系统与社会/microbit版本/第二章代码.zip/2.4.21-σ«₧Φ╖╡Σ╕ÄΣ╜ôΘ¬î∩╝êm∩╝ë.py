from microbit import *
while True:
    if uart.any():
        incoming = str(uart.readall(), "UTF-8")
        incoming=incoming.strip('\r')
        if incoming=='H':
            display.show(Image.HAPPY)
            print("I am happy")
        elif incoming=='S':
            display.show(Image.SAD)
            print("I am sad")
        else:
            print("err")